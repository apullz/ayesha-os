export interface ScreenSnapshot {
  id: string;
  timestamp: string;
  base64Image: string; // complete screen
  croppedImage?: string; // cropped base64 if user selected a region
  cropRect?: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

export interface OllamaModel {
  name: string;
  modified_at: string;
  size: number;
  digest: string;
  details?: {
    format: string;
    family: string;
    families: string[];
    parameter_size: string;
    quantization_level: string;
  };
}

export interface CustomModelfile {
  name: string;
  baseModel: string;
  systemPrompt: string;
  temperature?: number;
  topP?: number;
  topK?: number;
  stop?: string[];
  parametersList?: Array<{ key: string; value: string }>;
}

export interface AnalysisSession {
  id: string;
  timestamp: string;
  snapshot: ScreenSnapshot;
  prompt: string;
  taskMode: "general" | "ocr" | "ui-review" | "detector" | "bug-report" | "custom";
  modelUsed: string; // Ollama model or Moondream or Gemini Proxy
  engineType: "ollama" | "moondream-direct" | "gemini-proxy";
  result: string;
  isError?: boolean;
}

export interface ModelParameterOption {
  name: string;
  type: "number" | "string" | "boolean";
  description: string;
  defaultValue: string;
}
